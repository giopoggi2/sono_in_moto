<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
   <script src="script.js"></script>
   <link rel="stylesheet" href="style.css">
</head>

<body>
   <span id="titolo">
   <form action="Accedi2.php" method="post">
         <h1>Accedi</h1>
         <input type="text" name="username" id="" placeholder="Username">
         <input type="text" name="password" id="" placeholder="Password">
         <input type="submit" value="ACCEDI" name="pulsante">
      </form>
   </span>
</body>

</html>